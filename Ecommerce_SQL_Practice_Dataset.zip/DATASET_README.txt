E-Commerce SQL Practice Dataset (synthetic)
================================================
This is a fictional dataset created for SQL learning and internship task practice.
It contains no real customer information.

Tables:
- customers: customer_id (primary key)
- products: product_id (primary key)
- orders: order_id (primary key), customer_id (foreign key to customers)
- order_items: order_item_id (primary key), order_id (foreign key to orders), product_id (foreign key to products)
- payments: payment_id (primary key), order_id (foreign key to orders)

Suggested joins:
customers -> orders -> order_items -> products
orders -> payments

Note: Some customers have no orders and some orders have no payment row, enabling LEFT JOIN practice.
Order statuses and payment statuses are intentionally varied for filtering and aggregation exercises.
